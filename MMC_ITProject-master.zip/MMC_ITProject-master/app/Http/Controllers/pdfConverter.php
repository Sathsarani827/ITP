<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
Use PDF;

class pdfConverter extends Controller
{
    function index()
    {
        
    }
}
